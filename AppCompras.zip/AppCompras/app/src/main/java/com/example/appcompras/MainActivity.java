package com.example.appcompras;

import android.app.Activity;
import android.app.AlertDialog;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.CheckBox;

public class MainActivity extends Activity {

    // Declaração dos CheckBoxes e Botão
    CheckBox chkarroz, chkleite, chkcarne, chkfeijao, chkrefrigerante;
    Button bttotal;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        // Inicializando os CheckBoxes
        chkarroz = findViewById(R.id.chkarroz);
        chkleite = findViewById(R.id.chkleite);
        chkcarne = findViewById(R.id.chkcarne);
        chkfeijao = findViewById(R.id.chkfeijao);
        chkrefrigerante = findViewById(R.id.chkrefrigerante);

        // Inicializando o Botão
        bttotal = findViewById(R.id.bttotal);

        // Definindo a ação do botão de calcular o total
        bttotal.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                // Variável para armazenar o total da compra
                double total = 0;

                // Verificar quais itens estão selecionados e somar os valores
                if (chkarroz.isChecked()) {
                    total += 2.69;
                }
                if (chkleite.isChecked()) {
                    total += 5.00;
                }
                if (chkcarne.isChecked()) {
                    total += 10.00;
                }
                if (chkfeijao.isChecked()) {
                    total += 2.30;
                }
                if (chkrefrigerante.isChecked()) {
                    total += 2.00;
                }

                // Exibir o total em um AlertDialog
                AlertDialog.Builder dialogo = new AlertDialog.Builder(MainActivity.this);
                dialogo.setTitle("Aviso");
                dialogo.setMessage("Valor total da compra: R$ " + String.format("%.2f", total));
                dialogo.setNeutralButton("OK", null);
                dialogo.show();
            }
        });
    }
}